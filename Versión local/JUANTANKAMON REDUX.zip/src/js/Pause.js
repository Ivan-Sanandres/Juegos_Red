var Pause = new Phaser.Class({

    Extends: Phaser.Scene,

    initialize: function Pause ()
    {
        Phaser.Scene.call(this, { key: 'Pause'} ) //La key es la referencia en el código de esta escena para cuando la llamemos
    },

    preload: function () //Se cargan la fuente, las imágenes y la música de la escena
    {
        //this.load.image("b", "./resources/sprites/waitingRoomBackground.png");
        //this.load.image("buttonIcon", "./resources/sprites/sobreboton2.png");
        //this.load.image("buttonIconHover", "./resources/sprites/sobreboton.png");

    },

    create: function ()
    {
        var ES_pause = "PAUSA";
        var EN_pause = "PAUSE";
        var ES_mainmenu = "Volver al menú";
        var EN_mainmenu = "Return to menu";
        var ES_resume = "Continuar juego";
        var EN_resume = "Resume game";

        this.add.image(0, 0, "background").setOrigin(0, 0);
        var pauseTxt = this.add.bitmapText(152, 40, 'fuente', EN_pause, 22);
        if(spanish) pauseTxt.setText(ES_pause);

        var that = this;
        var contButton = new Button(this, this.cameras.main.width/2, 80, "buttonIcon", "buttonIconHover", EN_resume, 'fuente', function(that){
            that.scene.switch("LocalGame");
        }, 1.5,1);
        if(spanish) contButton.info.setText(ES_resume);
    
        var menuButton = new Button(this, this.cameras.main.width/2, 100, "buttonIcon", "buttonIconHover", EN_mainmenu, 'fuente', function(that){ 
            that.scene.stop("LocalGame");
            that.scene.start("Menu");
        }, 1.5,1);
        if(spanish) menuButton.info.setText(ES_mainmenu);
    }
});