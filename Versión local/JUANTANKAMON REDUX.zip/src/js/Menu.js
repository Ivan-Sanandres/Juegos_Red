//La variable la declaro global para que se guarde el valor para el juego. Si ya es true, cuando empiece el juego tampoco sonará música
var muted = false;
var spanish = false;

var endGameStates = {JUAN_WINS: "JUAN_WINS", GUARD_WINS: "GUARD_WINS", DISCONNECTION: "DISCONNECTION", PLAYING: "PLAYING"}
var endGameState = endGameStates.PLAYING;

//ESCENA MENÚ
var Menu = new Phaser.Class({

    Extends: Phaser.Scene,

    initialize: function Menu ()
    {
        Phaser.Scene.call(this, { key: 'Menu'} ) //La key es la referencia en el código de esta escena para cuando la llamemos
    },

    preload: function () //Se cargan la fuente, las imágenes y la música de la escena
    {
      this.load.bitmapFont('fuente', './resources/fonts/font/MC_0.png', './resources/fonts/font/MC.fnt');

      this.load.image("background", "./resources/sprites/background.png");
      this.load.image("wasd", "./resources/sprites/wasd.png");
      this.load.image("arrows", "./resources/sprites/arrows.png");
      this.load.image("buttonIcon", "./resources/sprites/sobreboton2.png");
      this.load.image("buttonIconHover", "./resources/sprites/sobreboton.png");

      this.load.audio("menuMusic", "./resources/sound/menuMusic.mp3");
    },

    create: function () //Código que se ejecuta al generarse la escena
    {

      var ES_musicText = "M: Poner/quitar música";
      var EN_musicText = "M: Mute/unmute music";
      var ES_pauseText = "P: Pausar juego";
      var EN_pauseText = "P: Pause game";
      var ES_musicButtonUNMT = "Activar música";
      var EN_musicButtonUNMT = "Unmute music";
      var ES_musicButtonMT = "Desactivar música";
      var EN_musicButtonMT = "Mute music";
      var ES_playButton = "Jugar";
      var EN_playButton = "Play";
      var ES_switchLang = "English";
      var EN_switchLang = "Español";
      var ES_returnButton = "Volver";
      var EN_returnButton = "Return";
      var ES_controlsButton = "Cómo jugar";
      var EN_controlsButton = "How to play";
      var ES_guardName = "Guardia";
      var EN_guardName = "Guard";
      var ES_juanDesc = [ '¡Tienes que salir',
                          'del museo! Reúne',
                          'llaves para abrir',
                          'las puertas.']
      var EN_juanDesc = [ 'You have to get out',
                          'of the museum! Find',
                          'all of the keys to',
                          'open the doors.']
      var ES_guardDesc = ['¡Atrapa a la momia!',
                          'Mueve la linterna',
                          'con el ratón. Puedes',
                          'atravesar puertas.']
      var EN_guardDesc = ['Catch the mummy!',
                          'Move the flashlight',
                          'with your mouse. You',
                          'can go through doors.']

      //Se añade la imagen de fondo del menú
      this.add.image(0, 0, "background").setOrigin(0, 0);

      //CREACIÓN DE TEXTOS
      this.add.bitmapText(74, 10, 'fuente', 'JUANTANKAMÓN', 33);
      this.add.bitmapText(152, 40, 'fuente', 'REDUX', 22);
      var musicText = this.add.bitmapText(this.cameras.main.width/2, 120, 'fuente', EN_musicText, 11).setOrigin(0.5,0);
      musicText.visible = false;
      var pauseText = this.add.bitmapText(this.cameras.main.width/2, 130, 'fuente', EN_pauseText, 11).setOrigin(0.5,0);
      pauseText.visible = false;

      // Al pulsar el botón de juego local se va a iniciar la escena de juego local
      var playButton = new Button(this, this.cameras.main.width/2, 80, "buttonIcon", "buttonIconHover", EN_playButton, 'fuente', function(that){
        menuMusic.stop();
        that.scene.start("LocalGame");
      }, 1.3,1);

      var langButton = new Button(this, this.cameras.main.width/2, 100, "buttonIcon", "buttonIconHover", EN_switchLang, 'fuente', function(that){ 
        spanish = !spanish;
        updateLanguage();
      }, 1.3,1);

      // Al pulsar el botón de juego online se va a iniciar la escena de buscar salas
      //var playOnlineButton = new Button(this, this.cameras.main.width/2, 105, 'buttonIcon', 'buttonIconHover', "Jugar online", 'fuente', function(that){
      //  menuMusic.stop();
      //  that.scene.start("SearchRooms");
      //}, 1.3,1);

      // Alternar entre música muteada o no, y cambiar el texto del botón correspondient2emente
      var musicButton = new Button(this, this.cameras.main.width/2 - 55, 165, 'buttonIcon', 'buttonIconHover', EN_musicButtonMT, 'fuente', function(that){
        muted = !muted;
        menuMusic.mute = muted;
        if(muted) {
          if(spanish) musicButton.info.setText(ES_musicButtonUNMT);
          if(!spanish) musicButton.info.setText(EN_musicButtonUNMT);
        } else {
          if(spanish) musicButton.info.setText(ES_musicButtonMT);
          if(!spanish) musicButton.info.setText(EN_musicButtonMT);
        }
      }, 1.6,1);

      function updateLanguage(){
        switch(spanish){
          case true:
            txtGuardia.setText(ES_guardName);
            musicText.setText(ES_musicText);
            pauseText.setText(ES_pauseText);
            txtDescG.setText(ES_guardDesc);
            txtDescJ.setText(ES_juanDesc);

            if(muted) {
              musicButton.info.setText(ES_musicButtonUNMT);
            } else {
              musicButton.info.setText(ES_musicButtonMT);
            }

            controlsButton.info.setText(ES_controlsButton);
            backButton.info.setText(ES_returnButton);
            playButton.info.setText(ES_playButton);
            langButton.info.setText(ES_switchLang);

            break;

          case false:
            txtGuardia.setText(EN_guardName);
            musicText.setText(EN_musicText);
            pauseText.setText(EN_pauseText);
            txtDescG.setText(EN_guardDesc);
            txtDescJ.setText(EN_juanDesc);
            
            if(muted) {
              musicButton.info.setText(EN_musicButtonUNMT);
            } else {
              musicButton.info.setText(EN_musicButtonMT);
            }

            controlsButton.info.setText(EN_controlsButton);
            backButton.info.setText(EN_returnButton);
            playButton.info.setText(EN_playButton);
            langButton.info.setText(EN_switchLang);  

            break;
        }
      }
      
      function control(){ // Alterna entre revelar y ocultar los elementos de la pantalla de menú principal y la de cómo jugar
        musicButton.icon.visible = !musicButton.icon.visible;
        musicButton.info.visible = !musicButton.info.visible;

        musicText.visible = !musicText.visible;
        pauseText.visible = !pauseText.visible;

        backButton.icon.visible = !backButton.icon.visible;
        backButton.info.visible = !backButton.info.visible;

        controlsButton.icon.visible = !controlsButton.icon.visible;
        controlsButton.info.visible = !controlsButton.info.visible;

        txtJuantankamon.visible = !txtJuantankamon.visible;
        txtGuardia.visible = !txtGuardia.visible;
        txtDescJ.visible = !txtDescJ.visible;
        txtDescG.visible = !txtDescG.visible;
        names1.visible = !names1.visible;
        names2.visible = !names2.visible;
        wasd.visible = !wasd.visible;
        arrows.visible = !arrows.visible;
      }

      // Botón que aparece en la pantalla de cómo jugar para volver a la pantalla principal
      var backButton = new Button(this, this.cameras.main.width/2, 165, 'buttonIcon', 'buttonIconHover', EN_returnButton, 'fuente', function(that){
        control();
      }, 1,1);

      backButton.icon.visible = false;
      backButton.info.visible = false;

      // Botón que aparece en el menú principal para acceder a la pantalla que explica cómo jugar
      var controlsButton = new Button(this, this.cameras.main.width/2 + 55, 165, 'buttonIcon', 'buttonIconHover', EN_controlsButton, 'fuente', function(that){
        control();
      }, 1.6,1);

      // Creación de textos que aparecerán en el menú principal
      names1 = this.add.bitmapText(this.cameras.main.width/5,   80, 'fuente', ['Martín Ariza',
                                                                               'Iván Sanandrés'], 11, 1).setOrigin(0.5, 0);
      names2 = this.add.bitmapText(this.cameras.main.width/5*4, 80, 'fuente', ['Pedro Casas',
                                                                               'Adrián Vaquero'], 11, 1).setOrigin(0.5, 0);

      txtJuantankamon = this.add.bitmapText(this.cameras.main.width/6, 70, 'fuente', 'Juantankamón', 11, 1).setOrigin(0.5, 0);
      txtGuardia = this.add.bitmapText(this.cameras.main.width/6*5, 70, 'fuente', EN_guardName, 11, 1).setOrigin(0.5, 0);
      txtDescJ = this.add.bitmapText(this.cameras.main.width/6,   113, 'fuente', EN_juanDesc, 11, 1).setOrigin(0.5, 0);
      txtDescG = this.add.bitmapText(this.cameras.main.width/6*5, 113, 'fuente', EN_guardDesc, 11, 1).setOrigin(0.5, 0);


      //Los textos que forman parte de la sección ¿Cómo jugar? se esconden para ser revelados cuando se active
      txtJuantankamon.visible = false;
      txtGuardia.visible = false;
      txtDescJ.visible = false;
      txtDescG.visible = false;

      //Se añaden las imágenes de las teclas para la sección ¿Cómo jugar? y se ocultan, igual que los textos
      wasd = this.add.image(this.cameras.main.width/6, 90, 'wasd').setOrigin(0.5, 0);
      wasd.visible = false;
      arrows = this.add.image(this.cameras.main.width/6*5, 90, 'arrows').setOrigin(0.5, 0);
      arrows.visible = false;

      //Se añade la música de fondo, se configura para que se reproduzca en bucle
      menuMusic = this.sound.add("menuMusic");
      menuMusic.play({mute: muted, loop: true});

      //Cada 5 segundos se hace un put del jugador para actualizarlo en el servidor
      //y que no se borre por inactividad
      //var timerInput = this.time.addEvent({
      //  delay: 5000,
      //  callback: periodicPut,
      //  //args: [],
      //  callbackScope: this,
      //  loop: true
      //});
      updateLanguage();
    },

});

//Actualiza en el servidor el jugador con los datos guardados en playerId, playerName y playerRoomId
//function periodicPut()
//{
//  var player = {
//    id: playerId,
//    name: playerName,
//    roomId: playerRoomId
//  }
//  AJAX_updatePlayer(player)
//}

// Se inicializan variables globales que van a ser necesarias tanto para LocalGame como para OnlineGame

var lightManager;

var anyInput = false;

var juan; //Contiene el objeto físico de Juan
var juanSpeed;
var juanMovementVector = new Phaser.Math.Vector2(0, 0);
var juanPreviousPos = new Phaser.Math.Vector2(0, 0);
var juanCursors; //Teclas con las que se mueve Juan
var juanCamera;
var juanLight;

var guard; //Contiene el objeto físico del guardia
var guardSpeed;
var guardMovementVector = new Phaser.Math.Vector2(0, 0);
var guardPreviousPos = new Phaser.Math.Vector2(0, 0);
var guardMouseVector = new Phaser.Math.Vector2(0, 0);
var guardCursors; //Teclas con las que se mueve el guardia
var guardCamera;
var guardLight;

var statics = {}; //Objetos estáticos de la escena

var doors = {};
var keys = {};
var spawnPoints = {};
var finalDoor;

var pointer;

var configKeys;

const numDoors = 4;
const numKeys = 4;

//var playingAsJuantankamon = true;
