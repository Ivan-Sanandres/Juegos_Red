var EndScreen = new Phaser.Class({

    Extends: Phaser.Scene,

    initialize: function EndScreen ()
    {
        Phaser.Scene.call(this, { key: 'EndScreen'} ) //La key es la referencia en el código de esta escena para cuando la llamemos
    },

    preload: function()
    {
        this.load.bitmapFont('fuente', './resources/fonts/font/MC_0.png', './resources/fonts/font/MC.fnt');

        this.load.image("juanWinsBackground", "./resources/sprites/juanWinsBackground.png");
        this.load.image("guardWinsBackground", "./resources/sprites/guardWinsBackground.png");
        this.load.image("buttonIcon", "./resources/sprites/sobreboton2.png");
        this.load.image("buttonIconHover", "./resources/sprites/sobreboton.png");
        //this.load.image("disconnectBackground", "./resources/sprites/disconnectBackground.png");
    },

    create: function()
    {
      var ES_juanWins = "Juantankamón gana";
      var EN_juanWins = "Juantankamón wins";
      var ES_guardWins = "El guardia gana";
      var EN_guardWins = "The guard wins";
      var ES_returnButton = "Volver al menú";
      var EN_returnButton = "Return to menu";
      var ES_tbcText = "Continuará...";
      var EN_tbcText = "To be continued";

      // Se establece el diseño de la escena en función de la causa por la que ha
      // terminado la partida (ha ganado Juan, el guardia, o ha habido una desconexión)
      if(endGameState == endGameStates.JUAN_WINS)
      {
          this.add.image(0, 0, 'juanWinsBackground').setOrigin(0, 0)
          var juanWins = this.add.bitmapText(92, 25, 'fuente', EN_juanWins, 22);
          if(spanish) juanWins.setText(ES_juanWins);
      }
      else if(endGameState == endGameStates.GUARD_WINS)
      {
          this.add.image(0, 0, 'guardWinsBackground').setOrigin(0, 0);
          var guardWins = this.add.bitmapText(102, 55, 'fuente', EN_guardWins, 22);
          if(spanish) guardWins.setText(ES_guardWins);
      }

      var tbcText = this.add.bitmapText(350, 172, "fuente", EN_tbcText, 11).setOrigin(1, 1);
      if(spanish) tbcText.setText(ES_tbcText);
      //else if(endGameState == endGameStates.DISCONNECT)
      //{
      //  this.add.image(0, 0, 'disconnectBackground').setOrigin(0, 0);
      //  this.add.bitmapText(122, 30, 'fuente', 'Desconexión', 22);
      //}

      //Al pulsar el botón de volver al menú y estar en la pantalla de desconexión
      //se le pide al jugador que vuelva a logearse
      var backButton = new Button(this, this.cameras.main.width/2, 20, 'buttonIcon', 'buttonIconHover', EN_returnButton, 'fuente', function(that){
        menuMusic.stop();
        /*if(endGameState != endGameStates.DISCONNECT)*/ that.scene.start("Menu");
        //else that.scene.start("NameInput");
      }, 1.6,1);
      
      if(spanish) backButton.info.setText(ES_returnButton);

      //Cada 5 segundos se hace un put del jugador para actualizarlo en el servidor
      //y que no se borre por inactividad
      //var timerInput = this.time.addEvent({
      //  delay: 5000,
      //  callback: function(){
      //    if(endGameState != endGameStates.DISCONNECT) periodicPut();
      //  },
      //  //args: [],
      //  callbackScope: this,
      //  loop: true
      //});
    }
})
